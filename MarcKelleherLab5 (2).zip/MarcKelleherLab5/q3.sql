/*
Marc Kelleher
CIS 276
Lab 5
2/12/18

3.	Write a PL/SQL program that includes an SQL statement that finds the partid, description, and price of the highest priced item in our inventory. 
Format your output line as "Part Number <vPartid> described as <vDescription> is the highest priced item in inventory at <vPrice>". 
Do not handle the case of there being two parts with the same, highest price - save that for the next question. Use the OTHERS EXCEPTION to display the SQLERRM. 
Your output line should look like the following: 

 Part Number 9999 described as XXXXXX is the highest priced item in inventory at $9999.999 
*/

SET SERVEROUTPUT ON FORMAT WRAPPED

DECLARE

    vPartID ORDERITEMS.PartID%TYPE;
    vDescription INVENTORY.Description%TYPE;
    vPrice INVENTORY.Price%TYPE;

BEGIN

    SELECT I.PartID, I.Description, NVL(MAX(I.Price),0)
    INTO vPartID, vDescription, vPrice
    FROM INVENTORY I
    GROUP BY I.PARTID, I.Description;
    DBMS_OUTPUT.PUT_LINE('CIS276 Lab5 q#3.
    Part Number ' || vPartID || ' described as ' || vDescription || ' is the highest priced item in inventory at ' || vPrice);

EXCEPTION

    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Lab5 q#3 OTHERS EXCEPTION');
        DBMS_OUTPUT.PUT_LINE(SQLERRM);

END;
/
