/*
Marc Kelleher
CIS 276
Lab 5
2/12/18

7.	Write a PL/SQL program with no CURSOR to input a custid and then display the customer's name and the total amount of all the customer's orders. 
The output for each test should be two values:  the customer's name and the total amount the customer has ordered. 
Test your program with a good customer id, a customer id that does not exist in the database, and a customer id that exists in the database but has no orders.  
Be sure to distinguish between a nonexistent customer and a customer that exists but has no orders (i.e. display different output for each situation) . 
Use the NO_DATA_FOUND and OTHERS EXCEPTION handlers.
*/

SET SERVEROUTPUT ON FORMAT WRAPPED

DECLARE

    inCustID    NUMBER(4) := &CustomerID;
    vCName      CUSTOMERS.CName%TYPE;
    v_TtlValue  NUMBER(8,2) := 0;
    vErrorMsg   VARCHAR2(512);

BEGIN

    SELECT  CUSTOMERS.CName
    INTO    vCName
    FROM    CUSTOMERS
    WHERE   CustID = inCustID;
    
    SELECT SUM(NVL(ORDERITEMS.Qty,0) * NVL(INVENTORY.Price,0))
    INTO v_TtlValue
    FROM CUSTOMERS  LEFT JOIN ORDERS ON CUSTOMERS.CustID = ORDERS.CustID
                    LEFT JOIN ORDERITEMS ON ORDERS.OrderID = ORDERITEMS.OrderID
                    LEFT JOIN INVENTORY ON ORDERITEMS.PartID = INVENTORY.PartID
    WHERE CUSTOMERS.CustID = inCustID
    GROUP BY CUSTOMERS.CustID;
    
    DBMS_OUTPUT.PUT_LINE('CIS276 Lab5 q#7.
Customer Name                                      Total Value');
    DBMS_OUTPUT.PUT_LINE(vCName || '                      ' || TO_CHAR(v_TtlValue, '$99,999.99'));

EXCEPTION

    WHEN NO_DATA_FOUND THEN
        vErrorMsg := 'CIS276 Lab 5 Question 7: NO_DATA_FOUND ERROR ';
        DBMS_OUTPUT.PUT_LINE(vErrorMsg);
        vErrorMsg := 'CIS276 Lab 5 Question 7: Customer ID not valid ' || TRIM(inCustID);
        DBMS_OUTPUT.PUT_LINE(vErrorMsg);
        
    WHEN OTHERS THEN
        vErrorMsg := 'CIS276 Lab 5 Question 7: OTHERS ERROR ';
        DBMS_OUTPUT.PUT_LINE(vErrorMsg);
        vErrorMsg := SQLERRM;         
        DBMS_OUTPUT.PUT_LINE(vErrorMsg);

END;
/
