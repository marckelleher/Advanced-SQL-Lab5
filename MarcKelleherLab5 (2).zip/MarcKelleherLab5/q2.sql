/*
Marc Kelleher
CIS 276
Lab 5
2/12/18

2.	Write a PL/SQL program that will include an SQL statement that finds the description and price for partid 1001.  
Declare variables vDescription and vPrice to hold the values you find; use another variable vPartid to store the partid above.  
Embed an SQL statement that will select the description and price values from the inventory table INTO the variables vDescription and vPrice.  
The WHERE clause should not check for the constant 1001, but rather check for the value in the variable vPartid. Use the OTHERS EXCEPTION to display the SQLERRM. 
Format your output line as "Part Number <vPartid> has a description of <vDescription> and costs <vPrice>". Your output line should look like: 

Part Number 1001 has a description of doodad and costs $10.00
*/

SET SERVEROUTPUT ON FORMAT WRAPPED

DECLARE

    vDescription INVENTORY.Description%TYPE;
    vPrice INVENTORY.Price%TYPE;
    vPartID ORDERITEMS.PartID%TYPE;
        
BEGIN
    
    vPartID := 1001; --Assigning the static value to vPartID.
    SELECT Description, Price
    INTO vDescription, vPrice
    FROM INVENTORY I
    WHERE I.PartID = vPartID;
    DBMS_OUTPUT.PUT_LINE('CIS276 Lab5 q#2.
    Part number ' || vPartID || ' has a description of ' || vDescription || ' and costs ' || vPrice);

EXCEPTION

    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Lab5 q#2 OTHERS EXCEPTION');
        DBMS_OUTPUT.PUT_LINE(SQLERRM);

END;
/
