/*
Marc Kelleher
CIS 276
Lab 5
2/12/18

6.	Write a PL/SQL program that accepts (&empid) an empid from the keyboard using variable substitution, and displays the name, employee number, and salary of the salesperson with the empid.  
Use the OTHERS EXCEPTION to display the SQLERRM. Format your output line as �<ename> (employee <empid>) earns <salary>�, i.e. your output should look something like: 

SQL> @q2
Enter value for myempid: 109
Kevin Kody      (employee  109) earns   $3,410.00

PL/SQL procedure successfully completed.
*/

SET SERVEROUTPUT ON FORMAT WRAPPED

DECLARE

    inEmpID NUMBER(4) := &EmpID;
    CURSOR cEmp IS
      SELECT S.EName, S.EmpID, S.Salary
      FROM SALESPERSONS S
      WHERE S.EmpID = inEmpID;
      
      vRow cEmp%ROWTYPE;
      
BEGIN

    OPEN cEmp;
    FETCH cEmp INTO vRow;
    DBMS_OUTPUT.PUT_LINE('CIS276 Lab5 q#6.
' || RTRIM(vRow.EName) || ' (employee  ' || vRow.EmpID || ') earns ' || TO_CHAR(vRow.Salary, '$99,999.99'));

EXCEPTION

    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Lab5 q#6 OTHERS EXCEPTION');
        DBMS_OUTPUT.PUT_LINE(SQLERRM);

END;
/

