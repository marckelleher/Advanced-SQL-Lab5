/*
Marc Kelleher
CIS 276
Lab 5
2/12/18

10.	Write a PL/SQL program to input a partid (&partid).  
Show the customers who have ordered this part by displaying the customer name, quantity ordered, and salesdate of order.  
Display the information in descending order of salesdate.  Test your program with a good partid, one that does not exist in the INVENTORY table, and one that no customer has ordered. 
Be sure to distinguish between a partid that does not exist and a partid that exists but has not been ordered. Use the NO_DATA_FOUND and OTHERS exception handlers. 
You can modify your INVENTORY table for the third test (I will be doing so when grading).

Please keep your output lines to 100 characters or less.
Do you have a test plan?
What kinds of errors can happen with each program you write above?
Is there output that tells the user what went wrong? 
Other new keywords of interest: SQLCODE, OPEN, CLOSE, %ROWTYPE, %ISOPEN, %FOUND, WHILE, DBMS_OUTPUT.PUT_LINE, SET SERVEROUTPUT ON, TOO_MANY_ROWS
*/

SET SERVEROUTPUT ON FORMAT WRAPPED

DECLARE
    
    inPartID    NUMBER(4) := &PartID;
    vCName      CUSTOMERS.CName%TYPE;
    vQty        ORDERITEMS.Qty%TYPE;
    vSalesDate  ORDERS.SalesDate%TYPE;
    
    CURSOR C_PartID IS
      SELECT    CUSTOMERS.CName, OI.Qty, O.SalesDate
      FROM      CUSTOMERS, ORDERITEMS OI, ORDERS O
      WHERE     inPartID = OI.PartID;
      
    v_Row C_PartID%ROWTYPE;  

BEGIN

    OPEN    C_PartID;
    FETCH   C_PartID INTO v_Row;
    WHILE   C_PartID%FOUND LOOP
    
      DBMS_OUTPUT.PUT_LINE( RTRIM(v_Row.CName) || ' ordered ' || v_Row.Qty || ' on ' || TO_CHAR(v_Row.SalesDate, 'MM/DD/YYYY'));
      
      FETCH C_PartID INTO v_Row;
    
    END LOOP;
    
    CLOSE C_PartID;

EXCEPTION

    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Lab5 q#10 OTHERS EXCEPTION');
        DBMS_OUTPUT.PUT_LINE(SQLERRM);

END;
/

