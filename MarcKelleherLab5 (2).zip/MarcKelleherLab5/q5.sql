/*
Marc Kelleher
CIS 276
Lab 5
2/12/18

5.	Write a PL/SQL program that displays the name, employee number, and salary of all salespersons in descending order of salary.  
This requires using a CURSOR and a LOOP with a FETCH. Use the OTHERS EXCEPTION to display the SQLERRM. 
Format your output line as �<ename> - <empid> <salary>�, i.e. your output should look something like the following:

109 - Kevin Kody        $3,100.00
108 - Harvey Harrison   $3,000.00
107 - Gloria Garcia     $2,500.00
106 - Faulkner Forest   $2,500.00
105 - Edward Everling   $2,200.00
104 - Dale Dahlman      $2,000.00
103 - Charles Cox       $2,000.00
110 - Larry Little      $1,500.00
102 - Burbank Burkett   $1,000.00
101 - Andrew Allen      $1,000.00
*/

SET SERVEROUTPUT ON FORMAT WRAPPED

DECLARE

    CURSOR all_salary IS
      SELECT    S.Ename, S.EmpID, S.Salary
      FROM      SALESPERSONS S
      ORDER BY  S.Salary DESC;
      
      s_Row all_salary%ROWTYPE;      

BEGIN
    
    OPEN  all_salary;
    FETCH all_salary INTO s_Row;
    WHILE all_salary%FOUND LOOP
    
      DBMS_OUTPUT.PUT_LINE(
      s_Row.EmpID || ' - ' || s_Row.Ename || ' ' || TO_CHAR(s_Row.Salary, '$9,999.99'));
      
      FETCH all_salary INTO s_Row;
      
END LOOP;      

EXCEPTION

    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Lab5 q#5 OTHERS EXCEPTION');
        DBMS_OUTPUT.PUT_LINE(SQLERRM);

END;
/
