/*
Marc Kelleher
CIS 276
Lab 5
2/12/18

8.	Write a PL/SQL program using a CURSOR for the same problem as #7 above. 
Do all the same tests as #7 and hopefully get the same results! Use the NO_DATA_FOUND and OTHERS exception handlers. 
The customer that has no orders can be checked using %ROWCOUNT in a condition. 
*/

SET SERVEROUTPUT ON FORMAT WRAPPED

DECLARE

    inCustID      NUMBER(4) := &CustID;
    vIfCustExists CHAR(1)   := 'n';
    
    CURSOR c_cust IS
      SELECT CUST.CName, NVL(SUM(OI.Qty*I.Price), 0) AS Ttl_Value
      FROM CUSTOMERS CUST, ORDERS O, ORDERITEMS OI, INVENTORY I
      WHERE CUST.CustID = O.CustID AND O.OrderID = OI.OrderID
      AND OI.PartID = I.PartID AND CUST.CustID = inCustID
      GROUP BY CUST.CName;
    
    v_Row c_cust%ROWTYPE;
    vErrorMsg VARCHAR2(512);

BEGIN

    SELECT 'Y'
    INTO vIfCustExists
    FROM CUSTOMERS CUST
    WHERE CUST.CustID = inCustID;
    
    OPEN c_cust;
    FETCH c_cust INTO v_Row;
  IF c_cust%ROWCOUNT > 0 THEN
    DBMS_OUTPUT.PUT_LINE('CIS276 Lab5 q#7.
Customer Name                                     Total Value');

  END IF;
  
    WHILE c_cust%FOUND LOOP
        DBMS_OUTPUT.PUT_LINE (v_Row.CName || '                     ' || TO_CHAR(v_Row.Ttl_Value, '$99,999.99'));
        FETCH c_cust INTO v_Row;
    END LOOP;  
    
    IF c_cust%ROWCOUNT = 0 THEN
        DBMS_OUTPUT.PUT_LINE ('Valid CustID ' || TRIM(inCustID) || ' has no orders');
    END IF;
    
    IF c_cust%ISOPEN THEN
        CLOSE c_cust;
    END IF;    
    
EXCEPTION

    WHEN NO_DATA_FOUND THEN
      vErrorMsg := 'CIS 276 Lab 5, Question 8 NO_DATA_FOUND Error';
      DBMS_OUTPUT.PUT_LINE (vErrorMsg);
      vErrorMsg := SQLERRM;
      DBMS_OUTPUT.PUT_LINE (vErrorMsg);
        IF c_cust %ISOPEN THEN
          CLOSE c_cust;
        END IF;
        
    WHEN OTHERS THEN
      vErrorMsg := 'CIS 276 Lab 5 Question #8 OTHERS ERROR';
      DBMS_OUTPUT.PUT_LINE(vErrorMsg);
      vErrorMsg := SQLERRM;
      DBMS_OUTPUT.PUT_LINE(SQLERRM);
        IF c_cust %ISOPEN THEN
          CLOSE c_cust;
        END IF;
END;
/
