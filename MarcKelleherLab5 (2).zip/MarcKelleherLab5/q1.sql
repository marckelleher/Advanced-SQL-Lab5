/*
Marc Kelleher
CIS 276
Lab 5
2/12/18

1.	Write a PL/SQL program that will declare two variables, vPartid and vDescription, and assign each values of 5001 and 'Gonzo' respectively.  
Format your output line as "Part Number <vPartid> has a description of <vDescription>". No exception processing needed. Note: this does not require a SQL statement. 
Produce an output line that looks like the following line: 

Part Number 5001 has a description of Gonzo

*/

SET SERVEROUTPUT ON FORMAT WRAPPED

DECLARE

    vPartID ORDERITEMS.PartID%TYPE;
    vDescription INVENTORY.Description%TYPE;

BEGIN

    vPartID := 5001;
    vDescription := 'Gonzo';
    DBMS_OUTPUT.PUT_LINE('CIS276 Lab5 q#1.
    Part Number ' || vPartID ||  ' has a description of '|| vdescription);

--EXCEPTION


END;
/
