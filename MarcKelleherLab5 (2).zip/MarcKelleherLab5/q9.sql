/*
Marc Kelleher
CIS 276
Lab 5
2/12/18

9.	Write a PL/SQL program to input a custid (&Custid).  
Display the customer�s name, and the orderid, salesdate, and total value of each order for that customer.  
Produce the output in descending order by total value of each order. This output will produce one or more lines for the customer, depending on how many orders that customer has made. 
Test your program with a good custid, a custid that is not in the CUSTOMERS table, and one that is in the CUSTOMERS table but has no orders.  
Be sure to distinguish between the customer that does not exist and a customer that exists but has no orders (as above: display different output for each situation).  
Use the NO_DATA_FOUND and OTHERS exception handlers. 
*/

SET SERVEROUTPUT ON FORMAT WRAPPED

DECLARE

    inCustID NUMBER(4)    := &CustID;
    vIfCustExists CHAR(1) := 'n';
    
     CURSOR c_cust IS
      SELECT    CUSTOMERS.CName, O.OrderID, O.SalesDate, SUM(OI.Qty*I.Price) AS Ttl_Value
      FROM      CUSTOMERS, ORDERS O, ORDERITEMS OI, INVENTORY I
      WHERE     CUSTOMERS.CustID = O.CustID AND O.OrderID = OI.OrderID
                AND OI.PartID = I.PartID AND CUSTOMERS.CustID = inCustID
      GROUP BY CUSTOMERS.CName, O.OrderID, O.SalesDate
      ORDER BY Ttl_Value;

      v_Row c_cust%ROWTYPE;
      VErrorMsg VARCHAR2(512);

BEGIN

    SELECT  'Y' 
    INTO    vIfCustExists
    FROM    CUSTOMERS
    WHERE   CustID = inCustID;
    
    OPEN    c_cust;
    FETCH   c_cust INTO v_Row;
    
    IF c_cust%ROWCOUNT > 0 THEN
    
        DBMS_OUTPUT.PUT_LINE('Customer Name               Order#   Date         TotalValue');
    
    END IF;    
    
    WHILE c_cust%FOUND LOOP
    
        DBMS_OUTPUT.PUT_LINE (v_Row.CName || '   ' ||
                              TRIM(v_Row.OrderID) || '     ' ||
                              TO_CHAR(v_Row.SalesDate, 'mm/dd/yy') || '   ' ||
                              TO_CHAR(v_Row.Ttl_Value, '$9999.99'));
        FETCH c_cust INTO v_Row;        
    
    END LOOP;
    
    IF c_cust%ROWCOUNT = 0 THEN 
        DBMS_OUTPUT.PUT_LINE (' Valid Customer ID ' || TRIM(inCustID) || ' with no orders');
    END IF;    

EXCEPTION

    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Lab5 q#9 OTHERS EXCEPTION');
        DBMS_OUTPUT.PUT_LINE(SQLERRM);

END;
/
