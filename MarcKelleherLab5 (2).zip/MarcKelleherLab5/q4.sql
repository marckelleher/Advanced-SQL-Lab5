/*
Marc Kelleher
CIS 276
Lab 5
2/12/18

4.	What would happen if there were two or more items that have that same highest price?  
(Let's say that the highest price is $80 and there are two or more items that have that price.)  
Write the PL/SQL program that would handle this situation.  This requires using a CURSOR and a LOOP with a FETCH.  
Use the OTHERS EXCEPTION to display the SQLERRM. Test your code for more than one item with the highest price.  
Update your table in order to test this condition (you can change a price in one of the already existing partid's to match the maximum price, or INSERT a new row).
*/

SET SERVEROUTPUT ON FORMAT WRAPPED

DECLARE

    CURSOR i_Price IS
      SELECT  I.PartID, I.Description, I.Price
        FROM  INVENTORY I
        WHERE I.Price IN (SELECT (MAX(I.Price))FROM INVENTORY I);
        
      i_Row i_Price%ROWTYPE;

BEGIN

    OPEN i_Price;
    FETCH i_Price INTO i_Row;
    WHILE i_Price%FOUND LOOP
    
      DBMS_OUTPUT.PUT_LINE('CIS276 Lab5 q#3.
      Part Number ' || i_Row.PartID || ' described as ' || RTRIM(i_Row.Description) || ' is the highest priced item in inventory at ' || LTRIM(TO_CHAR(i_Row.Price, '$999.99')));
      
      FETCH i_Price INTO i_Row;
      
    END LOOP;

CLOSE i_Price;

EXCEPTION

    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Lab5 q#4 OTHERS EXCEPTION');
        DBMS_OUTPUT.PUT_LINE(SQLERRM);

END;
/

